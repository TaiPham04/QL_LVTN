<?php

namespace App\Imports;

use App\Models\Student;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\BeforeImport;
use Exception;

class StudentsImport implements ToModel, WithHeadingRow, WithEvents
{
    // Danh sách cột chuẩn theo DB
    protected $expectedHeaders = ['mssv', 'hoten', 'lop', 'email', 'sdt'];

    public function registerEvents(): array
    {
        return [
            BeforeImport::class => function (BeforeImport $event) {
                $sheet = $event->reader->getDelegate()->getActiveSheet();
                $headerRow = $sheet->rangeToArray('A1:' . $sheet->getHighestColumn() . '1')[0];

                if (!$headerRow) {
                    throw new Exception("⚠️ File Excel không có hàng tiêu đề (header). Vui lòng kiểm tra lại!");
                }

                // Chuyển tiêu đề về chữ thường, bỏ dấu cách
                $normalizedHeader = array_map(fn($h) => strtolower(trim($h)), $headerRow);

                // Kiểm tra cột thiếu
                $missing = array_diff($this->expectedHeaders, $normalizedHeader);
                if (!empty($missing)) {
                    throw new Exception("⚠️ File Excel thiếu cột: " . implode(', ', $missing));
                }

                // Không cần báo cột dư – hệ thống tự bỏ qua
            },
        ];
    }

    public function model(array $row)
    {
        // Bỏ qua nếu thiếu thông tin bắt buộc
        if (
            empty($row['mssv']) ||
            empty($row['hoten']) ||
            empty($row['lop'])
        ) {
            return null; // bỏ qua dòng này
        }

        // Nếu MSSV đã tồn tại thì không thêm lại
        if (Student::where('mssv', trim($row['mssv']))->exists()) {
            return null;
        }

        // Thêm sinh viên mới
        return new Student([
            'mssv'  => trim($row['mssv']),
            'hoten' => trim($row['hoten']),
            'lop'   => trim($row['lop']),
            'email' => $row['email'] ?? null,
            'sdt'   => $row['sdt'] ?? null,
        ]);
    }
}
