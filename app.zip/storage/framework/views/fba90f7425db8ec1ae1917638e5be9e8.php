

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4 py-4">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="mb-1">Bảng phân công giảng viên</h4>
        </div>
        <a href="<?php echo e(route('admin.assignments.form')); ?>" class="btn btn-success">
            <i class="fas fa-plus me-2"></i>Phân công mới
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Filter -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.assignments.index')); ?>">
                <div class="row g-3">
                    <div class="col-md-4">
                        <input type="text" name="search" class="form-control" 
                               placeholder="Tìm theo MSSV, tên sinh viên..." 
                               value="<?php echo e(request('search')); ?>">
                    </div>
                    <div class="col-md-3">
                        <select name="magv" class="form-select">
                            <option value="">-- Tất cả giảng viên --</option>
                            <?php if(isset($lecturers)): ?>
                                <?php $__currentLoopData = $lecturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lecturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($lecturer->magv); ?>" <?php echo e(request('magv') == $lecturer->magv ? 'selected' : ''); ?>>
                                        <?php echo e($lecturer->hoten); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="status" class="form-select">
                            <option value="">-- Tất cả trạng thái --</option>
                            <option value="assigned" <?php echo e(request('status') == 'assigned' ? 'selected' : ''); ?>>Đã phân công</option>
                            <option value="unassigned" <?php echo e(request('status') == 'unassigned' ? 'selected' : ''); ?>>Chưa phân công</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-search me-2"></i>Tìm
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Assignments Table -->
    <div class="card border-0 shadow-sm">
        <div class="card-body">
            <?php if(isset($assignments) && count($assignments) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th style="width: 5%">STT</th>
                                <th style="width: 12%">MSSV</th>
                                <th style="width: 20%">Họ tên sinh viên</th>
                                <th style="width: 10%">Lớp</th>
                                <th style="width: 25%">Giảng viên hướng dẫn</th>
                                <th style="width: 12%">Có Đề Tài</th>
                                <th style="width: 8%" class="text-center">Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><strong><?php echo e($item->mssv); ?></strong></td>
                                    <td><?php echo e($item->hoten); ?></td>
                                    <td><?php echo e($item->lop ?? 'N/A'); ?></td>
                                    <td>
                                        <?php if($item->magv): ?>
                                            <?php echo e($item->tengiangvien ?? 'N/A'); ?>

                                            <span class="badge bg-success ms-2">Đã phân công</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Chưa phân công</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <?php if($item->co_de_tai): ?>
                                            <span class="badge bg-success">
                                                <i class="fas fa-check-circle me-1"></i>Có
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-warning text-dark">
                                                <i class="fas fa-times-circle me-1"></i>Chưa
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <?php if($item->magv): ?>
                                            <?php if($item->co_de_tai): ?>
                                                <!-- Sinh viên đã có đề tài → DISABLED -->
                                                <button class="btn btn-sm btn-outline-danger disabled" 
                                                        disabled 
                                                        title="Không thể hủy: Sinh viên đã có đề tài">
                                                    <i class="fas fa-times"></i>
                                                </button>
                                            <?php else: ?>
                                                <!-- Sinh viên chưa có đề tài → CÓ THỂ HỦY -->
                                                <form action="<?php echo e(route('admin.assignments.destroy', $item->mssv)); ?>" 
                                                      method="POST" 
                                                      style="display: inline;"
                                                      onsubmit="return confirm('Bạn có chắc muốn hủy phân công?')">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Hủy phân công">
                                                        <i class="fas fa-times"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <?php if(method_exists($assignments, 'links')): ?>
                    <div class="mt-3">
                        <?php echo e($assignments->links()); ?>

                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-clipboard-list fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted mb-2">Chưa có phân công nào</h5>
                    <p class="text-muted small mb-3">Bắt đầu phân công giảng viên cho sinh viên</p>
                    <a href="<?php echo e(route('admin.assignments.form')); ?>" class="btn btn-success">
                        <i class="fas fa-plus me-2"></i>Phân công ngay
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.card {
    border-radius: 12px;
}

.form-control, .form-select {
    border-radius: 8px;
    padding: 10px 14px;
}

.btn {
    border-radius: 8px;
    font-weight: 500;
}

.table th {
    font-weight: 600;
    color: #495057;
}

.badge {
    padding: 6px 12px;
    font-weight: 500;
}

.btn.disabled {
    cursor: not-allowed;
    opacity: 0.6;
}

.btn-outline-danger.disabled:hover {
    background-color: transparent;
    border-color: #dc3545;
    color: #dc3545;
}
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\QL_LVTN\resources\views/admin/assignments/index.blade.php ENDPATH**/ ?>