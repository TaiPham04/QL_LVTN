

<?php $__env->startSection('header', 'Danh sách sinh viên'); ?>

<?php $__env->startSection('content'); ?>
<div class="container"> 
    <div class="d-flex justify-content-between mb-3">
        <h4>Danh sách sinh viên</h4>
        <div>
            <a href="" class="btn btn-success">Xuất file excel</a>

            
            <?php if(session('user') && session('user')->role === 'admin'): ?>
                <a href="<?php echo e(route('students.create')); ?>" class="btn btn-primary">+ Thêm sinh viên</a>
            <?php endif; ?>
        </div>
    </div>


    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-hover">
        <thead class="table-light">
            <tr>
                <th>MSSV</th>
                <th>Họ tên</th>
                <th>Lớp</th>
                <th>SĐT</th>
                <th>Email</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($sv->mssv); ?></td>
                    <td><?php echo e($sv->hoten); ?></td>
                    <td><?php echo e($sv->lop); ?></td>
                    <td><?php echo e($sv->sdt); ?></td>
                    <td><?php echo e($sv->email); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\QL_LVTN\resources\views/students/index.blade.php ENDPATH**/ ?>