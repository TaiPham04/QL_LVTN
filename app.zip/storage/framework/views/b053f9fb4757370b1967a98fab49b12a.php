

<?php $__env->startSection('title', 'Trang chủ'); ?>
<?php $__env->startSection('header', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow-sm">
    <div class="card-body">
        <h3 class="text-primary fw-bold">Home</h3>
        <p>Chào mừng bạn đến hệ thống quản lý luận văn tốt nghiệp sinh viên.</p>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\QL_LVTN\resources\views/dashboard.blade.php ENDPATH**/ ?>