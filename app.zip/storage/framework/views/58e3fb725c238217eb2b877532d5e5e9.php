

<?php $__env->startSection('header', 'Phân công đề tài'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4 class="mb-3">Phân công đề tài</h4>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    
    <div class="d-flex justify-content-start gap-2 mb-3">
        <button form="assignmentForm" type="submit" class="btn btn-success">
            <i class="bi bi-save"></i> Lưu phân công
        </button>
        <button type="button" class="btn btn-danger" id="deleteButton">
            <i class="bi bi-trash"></i> Xóa thông tin
        </button>
    </div>

    
    <form action="<?php echo e(route('lecturers.assignments.store')); ?>" method="POST" id="assignmentForm">
        <?php echo csrf_field(); ?>
        <table class="table table-bordered table-hover">
            <thead class="table-light">
                <tr>
                    <th style="width: 40px; text-align:center;">
                        <input type="checkbox" id="selectAll">
                    </th>
                    <th>MSSV</th>
                    <th>Họ tên</th>
                    <th>Nhóm</th>
                    <th>Tên đề tài</th>
                    <th>Trạng thái</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center">
                            <input type="checkbox" name="students[]" value="<?php echo e($sv->mssv); ?>" class="student-checkbox">
                        </td>
                        <td><?php echo e($sv->mssv); ?></td>
                        <td><?php echo e($sv->hoten); ?></td>
                        <td><?php echo e($sv->nhom ?? 'Chưa có'); ?></td>
                        <td>
                            <input type="text" name="titles[<?php echo e($sv->mssv); ?>]" class="form-control"
                                   value="<?php echo e($sv->tendt ?? ''); ?>" placeholder="Nhập tên đề tài">
                        </td>
                        <td>
                            <input type="text" name="statuses[<?php echo e($sv->mssv); ?>]" class="form-control"
                                   value="<?php echo e($sv->trangthai ?? ''); ?>" placeholder="VD: Đang thực hiện">
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </form>

    
    <form id="deleteForm" action="<?php echo e(route('lecturers.assignments.delete')); ?>" method="POST" style="display:none;">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="students" id="deleteStudents">
    </form>
</div>


<script>
    // Xử lý checkbox "Chọn tất cả"
    document.getElementById('selectAll').addEventListener('change', function () {
        const checked = this.checked;
        document.querySelectorAll('.student-checkbox').forEach(cb => cb.checked = checked);
    });

    // Xử lý nút XÓA
    document.getElementById('deleteButton').addEventListener('click', function () {
        const selected = Array.from(document.querySelectorAll('.student-checkbox:checked'))
            .map(cb => cb.value);

        if (selected.length === 0) {
            alert('⚠️ Vui lòng chọn ít nhất 1 sinh viên để xóa!');
            return;
        }

        if (!confirm('Bạn có chắc chắn muốn xóa thông tin các sinh viên được chọn không?')) {
            return;
        }

        document.getElementById('deleteStudents').value = JSON.stringify(selected);
        document.getElementById('deleteForm').submit();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\QL_LVTN\resources\views/assignments/lecturer-form.blade.php ENDPATH**/ ?>