

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Phân công giảng viên cho sinh viên</h2>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('assignments.bulkSave')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="d-flex align-items-center mb-3">
            <label for="magv" class="me-2 fw-bold">Chọn giảng viên:</label>
            <select name="magv" id="magv" class="form-control w-auto me-3">
                <option value="">-- Chọn giảng viên --</option>
                <?php $__currentLoopData = $lecturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lecturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($lecturer->magv); ?>"><?php echo e($lecturer->hoten); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <button type="submit" class="btn btn-success">Lưu phân công</button>
        </div>

        <?php if($students->isEmpty()): ?>
            <div class="alert alert-info">🎉 Tất cả sinh viên đã được phân công!</div>
        <?php else: ?>
            <table class="table table-bordered align-middle">
                <thead class="table-light">
                    <tr>
                        <th>
                            <input type="checkbox" id="checkAll"> <!-- check all -->
                        </th>
                        <th>MSSV</th>
                        <th>Họ tên</th>
                        <th>Lớp</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><input type="checkbox" name="students[]" value="<?php echo e($student->mssv); ?>" class="student-checkbox"></td>
                        <td><?php echo e($student->mssv); ?></td>
                        <td><?php echo e($student->hoten); ?></td>
                        <td><?php echo e($student->lop); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </form>
</div>

<script>
    // check all / uncheck all
    document.getElementById('checkAll').addEventListener('change', function(e) {
        document.querySelectorAll('.student-checkbox').forEach(cb => cb.checked = e.target.checked);
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\QL_LVTN\resources\views/assignments/form.blade.php ENDPATH**/ ?>