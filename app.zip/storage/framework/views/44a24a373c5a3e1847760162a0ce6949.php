

<?php $__env->startSection('header', 'Chỉnh sửa giảng viên'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h5>Chỉnh sửa thông tin giảng viên</h5>

    <form action="<?php echo e(route('lecturers.update', $lecturer->magv)); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="hoten" class="form-label">Họ tên</label>
            <input type="text" name="hoten" id="hoten" class="form-control"
                   value="<?php echo e(old('hoten', $lecturer->hoten)); ?>" required>
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" name="email" id="email" class="form-control"
                   value="<?php echo e(old('email', $lecturer->email)); ?>" required>
        </div>

        <div class="text-end">
            <button type="submit" class="btn btn-primary">Cập nhật</button>
            <a href="<?php echo e(route('lecturers.edit.list')); ?>" class="btn btn-secondary">Quay lại</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\QL_LVTN\resources\views/lecturers/edit-form.blade.php ENDPATH**/ ?>