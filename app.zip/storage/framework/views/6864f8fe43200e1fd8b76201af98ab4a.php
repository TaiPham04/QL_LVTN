

<?php $__env->startSection('header', 'Sửa sinh viên'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h5>Danh sách sinh viên - Chỉnh sửa</h5>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-hover align-middle">
        <thead class="table-light">
            <tr>
                <th>MSSV</th>
                <th>Họ tên</th>
                <th>Lớp</th>
                <th>SĐT</th>
                <th>Email</th>
                <th class="text-center" style="width:120px;">Thao tác</th> 
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($sv->mssv); ?></td>
                    <td><?php echo e($sv->hoten); ?></td>
                    <td><?php echo e($sv->lop); ?></td>
                    <td><?php echo e($sv->sdt); ?></td>
                    <td><?php echo e($sv->email); ?></td>
                    <td class="text-center">
                        <a href="<?php echo e(route('students.edit', $sv->mssv)); ?>" class="btn btn-sm btn-warning">
                            <i class="fa fa-edit"></i> Sửa
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\QL_LVTN\resources\views/students/edit.blade.php ENDPATH**/ ?>