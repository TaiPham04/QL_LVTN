

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4 class="mb-3">Danh sách đề tài</h4>

    
    <form method="GET" action="<?php echo e(route('admin.topics.index')); ?>" class="mb-3">
        <div class="row g-2 align-items-end">
            <div class="col-md-4">
                <label for="lecturer" class="form-label fw-bold">Lọc theo giảng viên:</label>
                <select name="lecturer" id="lecturer" class="form-select" onchange="this.form.submit()">
                    <option value="">-- Tất cả giảng viên --</option>
                    <?php $__currentLoopData = $lecturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($gv->tengv); ?>" <?php echo e(request('lecturer') == $gv->tengv ? 'selected' : ''); ?>>
                            <?php echo e($gv->tengv); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <label for="status" class="form-label fw-bold">Trạng thái đề tài:</label>
                <select name="status" id="status" class="form-select" onchange="this.form.submit()">
                    <option value="">-- Tất cả --</option>
                    <option value="co_detai" <?php echo e(request('status') == 'co_detai' ? 'selected' : ''); ?>>✅ Có đề tài</option>
                    <option value="chua_detai" <?php echo e(request('status') == 'chua_detai' ? 'selected' : ''); ?>>❌ Chưa có đề tài</option>
                </select>
            </div>
        </div>
    </form>

    <div class="table-responsive">
        <table class="table table-bordered">
            <thead class="table-light">
                <tr>
                    <th style="width: 80px;" class="text-center">Nhóm</th>
                    <th style="width: 120px;">MSSV</th>
                    <th style="width: 220px;">Tên sinh viên</th>
                    <th>Tên đề tài</th>
                    <th style="width: 180px;">Giảng viên HD</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $groupedTopics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php $studentCount = count($group['students']); ?>
                    <?php $__currentLoopData = $group['students']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php if($index === 0): ?>
                                
                                <td rowspan="<?php echo e($studentCount); ?>" class="text-center align-middle">
                                    <?php if($group['nhom']): ?>
                                        <span class="badge bg-secondary fs-6"><?php echo e($group['nhom']); ?></span>
                                    <?php else: ?>
                                        <span class="text-muted">Chưa có</span>
                                    <?php endif; ?>
                                </td>
                            <?php endif; ?>
                            
                            
                            <td><?php echo e($student['mssv']); ?></td>
                            <td><?php echo e($student['tensv']); ?></td>
                            
                            <?php if($index === 0): ?>
                                
                                <td rowspan="<?php echo e($studentCount); ?>" class="align-middle">
                                    <?php if($group['tendt']): ?>
                                        <?php echo e($group['tendt']); ?>

                                    <?php else: ?>
                                        <span class="text-danger fst-italic">Chưa có đề tài</span>
                                    <?php endif; ?>
                                </td>
                                <td rowspan="<?php echo e($studentCount); ?>" class="align-middle">
                                    <small class="text-primary">
                                        <i class="bi bi-person-badge"></i> <?php echo e($group['tengv']); ?>

                                    </small>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted py-4">
                            <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                            Không tìm thấy dữ liệu phù hợp.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if(count($groupedTopics) > 0): ?>
        <div class="mt-3 text-muted">
            <i class="bi bi-info-circle"></i> 
            Tổng: <strong><?php echo e(count($groupedTopics)); ?></strong> nhóm
            (<?php echo e(collect($groupedTopics)->sum(fn($g) => count($g['students']))); ?> sinh viên)
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\QL_LVTN\resources\views/admin/topics/index.blade.php ENDPATH**/ ?>