

<?php $__env->startSection('header', 'Phân Công Đề Tài Cho Hội Đồng'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            
            <div class="card mb-3">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">
                        <i class="fa fa-info-circle me-2"></i>
                        Hội Đồng: <strong><?php echo e($hoiDong->tenhd); ?></strong> (<?php echo e($hoiDong->mahd); ?>)
                    </h5>
                </div>
                <div class="card-body">
                    <p class="mb-0">
                        <strong>Số thành viên:</strong> <?php echo e($hoiDong->thanhVien->count()); ?>/3 |
                        <strong>Số đề tài đã phân công:</strong> <?php echo e($deTaiDaPhanCong->count()); ?>

                    </p>
                </div>
            </div>

            
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="fa fa-check-circle me-2"></i><?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <i class="fa fa-exclamation-circle me-2"></i><?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="row">
                
                <div class="col-lg-6 col-md-12 mb-3">
                    <div class="card">
                        <div class="card-header bg-warning text-dark">
                            <h5 class="mb-0">
                                <i class="fa fa-list me-2"></i> 
                                Đề Tài Chưa Phân Công (<?php echo e($deTaiKhaDung->count()); ?>)
                            </h5>
                        </div>
                        <div class="card-body" style="max-height: 600px; overflow-y: auto;">
                            <?php if($deTaiKhaDung->isEmpty()): ?>
                                <div class="alert alert-info">
                                    <i class="fa fa-info-circle me-2"></i>
                                    Không còn đề tài nào khả dụng để phân công.
                                </div>
                            <?php else: ?>
                                <form action="<?php echo e(route('admin.hoidong.phancong.store', $hoiDong->mahd)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>

                                    <div class="alert alert-info">
                                        <i class="fa fa-info-circle me-2"></i>
                                        <strong>Lưu ý:</strong> Chỉ hiển thị đề tài mà GV hướng dẫn KHÔNG thuộc hội đồng này.
                                    </div>

                                    <?php $__currentLoopData = $deTaiKhaDung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card mb-2 border-warning">
                                        <div class="card-body p-3">
                                            <div class="form-check">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="nhom[]" 
                                                       value="<?php echo e($dt->nhom); ?>" 
                                                       id="nhom_<?php echo e($dt->nhom); ?>">
                                                <label class="form-check-label w-100" for="nhom_<?php echo e($dt->nhom); ?>">
                                                    <strong class="text-primary"><?php echo e($dt->nhom); ?></strong> - <?php echo e($dt->tendt); ?>

                                                    <br>
                                                    <small class="text-muted">
                                                        GV: <?php echo e($dt->gv_huongdan); ?> (<?php echo e($dt->magv); ?>)
                                                    </small>
                                                    <br>
                                                    <small>
                                                        <strong>Sinh viên:</strong>
                                                        <?php $__currentLoopData = $sinhVienTheoNhom[$dt->nhom]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php echo e($sv->hoten); ?> (<?php echo e($sv->mssv); ?>)<?php if(!$loop->last): ?>, <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </small>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <div class="text-center mt-3">
                                        <button type="submit" class="btn btn-primary btn-lg">
                                            <i class="fa fa-check me-2"></i> Phân Công Đề Tài Đã Chọn
                                        </button>
                                    </div>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                
                <div class="col-lg-6 col-md-12 mb-3">
                    <div class="card">
                        <div class="card-header bg-success text-white">
                            <h5 class="mb-0">
                                <i class="fa fa-check-circle me-2"></i> 
                                Đề Tài Đã Phân Công (<?php echo e($deTaiDaPhanCong->count()); ?>)
                            </h5>
                        </div>
                        <div class="card-body" style="max-height: 600px; overflow-y: auto;">
                            <?php if($deTaiDaPhanCong->isEmpty()): ?>
                                <div class="alert alert-warning">
                                    <i class="fa fa-exclamation-triangle me-2"></i>
                                    Chưa có đề tài nào được phân công!
                                </div>
                            <?php else: ?>
                                <?php $__currentLoopData = $deTaiDaPhanCong; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card mb-2 border-success">
                                    <div class="card-header bg-success bg-opacity-10 py-2">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <strong class="text-success">
                                                <?php echo e($index + 1); ?>. <?php echo e($dt->nhom); ?>

                                            </strong>
                                            <form action="<?php echo e(route('admin.hoidong.phancong.delete', [$hoiDong->mahd, $dt->nhom])); ?>" 
                                                  method="POST" 
                                                  onsubmit="return confirm('Xác nhận xóa đề tài này?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="card-body p-3">
                                        <p class="mb-1"><strong><?php echo e($dt->tendt); ?></strong></p>
                                        <p class="mb-1 text-muted small">
                                            GV: <?php echo e($dt->gv_huongdan); ?> (<?php echo e($dt->magv); ?>)
                                        </p>
                                        <hr class="my-2">
                                        <p class="mb-0 small">
                                            <strong>Sinh viên:</strong><br>
                                            <?php $__currentLoopData = $sinhVienDaPhanCong[$dt->nhom]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class="badge bg-secondary me-1"><?php echo e($sv->hoten); ?></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </p>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="text-center mt-3">
                <a href="<?php echo e(route('admin.hoidong.show', $hoiDong->mahd)); ?>" class="btn btn-secondary btn-lg">
                    <i class="fa fa-arrow-left me-2"></i> Quay Lại Chi Tiết Hội Đồng
                </a>
                <a href="<?php echo e(route('admin.hoidong.index')); ?>" class="btn btn-outline-secondary btn-lg">
                    <i class="fa fa-list me-2"></i> Danh Sách Hội Đồng
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\QL_LVTN\resources\views/hoidong/phan-cong.blade.php ENDPATH**/ ?>