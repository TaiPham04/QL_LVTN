

<?php $__env->startSection('title', 'Bảng Phân Công'); ?>
<?php $__env->startSection('header', 'Bảng Phân Công Hướng Dẫn'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card shadow-sm">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('assignments.index')); ?>" class="row g-3 align-items-center">
                <div class="col-auto">
                    <label for="magv" class="col-form-label fw-semibold">Chọn giảng viên:</label>
                </div>
                <div class="col-auto">
                    <select name="magv" id="magv" class="form-select" onchange="this.form.submit()">
                        <option value="">-- Tất cả --</option>
                        <?php $__currentLoopData = $lecturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($gv->magv); ?>" <?php echo e($selectedLecturer == $gv->magv ? 'selected' : ''); ?>>
                                <?php echo e($gv->hoten); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </form>

            <table class="table table-striped mt-4 align-middle">
                <thead class="table-primary">
                    <tr>
                        <th>MSSV</th>
                        <th>Họ tên sinh viên</th>
                        <th>Lớp</th>
                        <th>Giảng viên hướng dẫn</th>
                        <th>Thời gian phân công</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($a->student->mssv); ?></td>
                            <td><?php echo e($a->student->hoten); ?></td>
                            <td><?php echo e($a->student->lop); ?></td>
                            <td><?php echo e($a->lecturer->hoten); ?></td>
                            <td><?php echo e($a->tg_phancong); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted py-3">Không có dữ liệu phân công</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\QL_LVTN\resources\views/assignments/index.blade.php ENDPATH**/ ?>