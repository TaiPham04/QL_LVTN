

<?php $__env->startSection('header', 'Quản Lý Hội Đồng'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">
                        <i class="fa fa-users me-2"></i> Danh Sách Hội Đồng
                    </h4>
                    <a href="<?php echo e(route('admin.hoidong.create')); ?>" class="btn btn-light btn-sm">
                        <i class="fa fa-plus me-1"></i> Tạo Hội Đồng Mới
                    </a>
                </div>

                <div class="card-body">
                    
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fa fa-check-circle me-2"></i><?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="fa fa-exclamation-circle me-2"></i><?php echo e(session('error')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    
                    <?php if($danhSachHoiDong->isEmpty()): ?>
                        <div class="alert alert-warning text-center">
                            <i class="fa fa-exclamation-triangle fa-3x mb-3"></i>
                            <h5>Chưa có hội đồng nào</h5>
                            <p class="mb-0">Nhấn nút "Tạo Hội Đồng Mới" để bắt đầu.</p>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <thead class="table-light">
                                    <tr>
                                        <th width="5%" class="text-center">STT</th>
                                        <th width="15%">Mã Hội Đồng</th>
                                        <th width="30%">Tên Hội Đồng</th>
                                        <th width="10%" class="text-center">Thành Viên</th>
                                        <th width="10%" class="text-center">Đề Tài</th>
                                        <th width="10%" class="text-center">Trạng Thái</th>
                                        <th width="20%" class="text-center">Thao Tác</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $danhSachHoiDong; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $hd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($index + 1); ?></td>
                                        <td>
                                            <strong class="text-primary"><?php echo e($hd->mahd); ?></strong>
                                        </td>
                                        <td><?php echo e($hd->tenhd); ?></td>
                                        <td class="text-center">
                                            <?php if($hd->so_thanh_vien == 3): ?>
                                                <span class="badge bg-success">
                                                    <i class="fa fa-check me-1"></i><?php echo e($hd->so_thanh_vien); ?>/3
                                                </span>
                                            <?php else: ?>
                                                <span class="badge bg-warning text-dark">
                                                    <i class="fa fa-exclamation me-1"></i><?php echo e($hd->so_thanh_vien); ?>/3
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-info"><?php echo e($hd->so_de_tai); ?> đề tài</span>
                                        </td>
                                        <td class="text-center">
                                            <?php if($hd->trang_thai == 'dang_mo'): ?>
                                                <span class="badge bg-success">Đang mở</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">Đã đóng</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('admin.hoidong.show', $hd->mahd)); ?>" 
                                               class="btn btn-sm btn-info" title="Chi tiết">
                                                <i class="fa fa-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('admin.hoidong.phancong.form', $hd->mahd)); ?>" 
                                               class="btn btn-sm btn-primary" title="Phân công">
                                                <i class="fa fa-tasks"></i>
                                            </a>

                                            <?php if($hd->so_de_tai > 0): ?>
                                                <a href="<?php echo e(route('admin.hoidong.export.excel', $hd->mahd)); ?>" 
                                                class="btn btn-sm btn-success" 
                                                title="Xuất Excel">
                                                    <i class="fa fa-file-excel"></i>
                                                </a>
                                            <?php endif; ?>
                                            
                                            
                                            <?php if($hd->so_de_tai == 0): ?>
                                                <form action="<?php echo e(route('admin.hoidong.destroy', $hd->mahd)); ?>" 
                                                    method="POST" class="d-inline" 
                                                    onsubmit="return confirm('Xác nhận xóa hội đồng này?')">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-danger" title="Xóa">
                                                        <i class="fa fa-trash"></i>
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                
                                                <button type="button" 
                                                        class="btn btn-sm btn-secondary" 
                                                        title="Không thể xóa vì đã có <?php echo e($hd->so_de_tai); ?> đề tài"
                                                        disabled>
                                                    <i class="fa fa-lock"></i>
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\QL_LVTN\resources\views/hoidong/index.blade.php ENDPATH**/ ?>