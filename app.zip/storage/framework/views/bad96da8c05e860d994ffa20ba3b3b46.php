

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-warning text-dark">
                    <h4 class="mb-0">
                        <i class="fa fa-user-check me-2"></i>
                        Chấm Điểm Phản Biện
                    </h4>
                </div>

                <div class="card-body">
                    
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fa fa-check-circle me-2"></i><?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="fa fa-exclamation-circle me-2"></i><?php echo e(session('error')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if(session('info')): ?>
                        <div class="alert alert-info alert-dismissible fade show" role="alert">
                            <i class="fa fa-info-circle me-2"></i><?php echo e(session('info')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    
                    <div class="alert alert-info">
                        <i class="fa fa-info-circle me-2"></i>
                        <strong>Hướng dẫn:</strong> Dưới đây là danh sách các nhóm bạn được phân công phản biện. 
                        Nhấn vào nút "Chấm điểm" để thực hiện chấm điểm phản biện.
                    </div>

                    
                    <?php if($danhSachNhom->isEmpty()): ?>
                        <div class="alert alert-warning text-center">
                            <i class="fa fa-exclamation-triangle fa-3x mb-3"></i>
                            <h5>Chưa có nhóm nào cần chấm điểm phản biện</h5>
                            <p class="mb-0">Hiện tại bạn chưa được phân công phản biện nhóm nào.</p>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <thead class="table-warning">
                                    <tr>
                                        <th width="5%" class="text-center">STT</th>
                                        <th width="10%" class="text-center">Mã Nhóm</th>
                                        <th width="40%">Tên Đề Tài</th>
                                        <th width="10%" class="text-center">Số SV</th>
                                        <th width="15%" class="text-center">Trạng Thái</th>
                                        <th width="20%" class="text-center">Thao Tác</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $danhSachNhom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $nhom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($index + 1); ?></td>
                                        <td class="text-center">
                                            <strong class="badge bg-secondary"><?php echo e($nhom->nhom); ?></strong>
                                        </td>
                                        <td><?php echo e($nhom->tendt); ?></td>
                                        <td class="text-center">
                                            <span class="badge bg-info"><?php echo e($nhom->so_luong_sv); ?> sinh viên</span>
                                        </td>
                                        <td class="text-center">
                                            <?php if($nhom->da_cham): ?>
                                                <span class="badge bg-success">
                                                    <i class="fa fa-check me-1"></i>Đã chấm
                                                </span>
                                            <?php else: ?>
                                                <span class="badge bg-warning text-dark">
                                                    <i class="fa fa-clock me-1"></i>Chưa chấm
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('lecturers.chamdiem.phanbien.form', $nhom->nhom)); ?>" 
                                               class="btn btn-sm <?php echo e($nhom->da_cham ? 'btn-warning' : 'btn-primary'); ?>">
                                                <i class="fa <?php echo e($nhom->da_cham ? 'fa-edit' : 'fa-pen'); ?> me-1"></i>
                                                <?php echo e($nhom->da_cham ? 'Sửa điểm' : 'Chấm điểm'); ?>

                                            </a>

                                            <?php if($nhom->da_cham): ?>
                                                <a href="<?php echo e(route('lecturers.chamdiem.phanbien.export', $nhom->nhom)); ?>" 
                                                   class="btn btn-sm btn-success">
                                                    <i class="fa fa-file-word me-1"></i>Xuất Word
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\QL_LVTN\resources\views/lecturers/cham-diem/phan-bien/index.blade.php ENDPATH**/ ?>