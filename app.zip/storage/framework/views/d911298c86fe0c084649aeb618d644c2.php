

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2 class="mb-3">Trang chủ Admin</h2>
    <p>Xin chào, <?php echo e(session('user')->name ?? 'Admin'); ?> 👋</p>
    <p>Chọn một chức năng trong menu để bắt đầu làm việc.</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\QL_LVTN\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>