

<?php $__env->startSection('header', 'Tạo Hội Đồng Mới'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <form action="<?php echo e(route('admin.hoidong.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        
        <div class="row">
            <div class="col-lg-8 col-md-12 mx-auto">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">
                            <i class="fa fa-plus-circle me-2"></i> Tạo Hội Đồng Mới
                        </h4>
                    </div>

                    <div class="card-body">
                        
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger alert-dismissible fade show">
                                <i class="fa fa-exclamation-circle me-2"></i><?php echo e(session('error')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        
                        <div class="mb-3">
                            <label for="mahd" class="form-label fw-bold">
                                Mã Hội Đồng <span class="text-danger">*</span>
                            </label>
                            <input type="text" 
                                   class="form-control <?php $__errorArgs = ['mahd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   id="mahd" 
                                   name="mahd" 
                                   value="<?php echo e(old('mahd')); ?>" 
                                   placeholder="VD: HD2025_01" 
                                   required>
                            <?php $__errorArgs = ['mahd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <small class="text-muted">Tối đa 20 ký tự, không trùng với hội đồng đã có</small>
                        </div>

                        
                        <div class="mb-3">
                            <label for="tenhd" class="form-label fw-bold">
                                Tên Hội Đồng <span class="text-danger">*</span>
                            </label>
                            <input type="text" 
                                   class="form-control <?php $__errorArgs = ['tenhd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   id="tenhd" 
                                   name="tenhd" 
                                   value="<?php echo e(old('tenhd')); ?>" 
                                   placeholder="VD: Hội đồng bảo vệ ĐATN K19 - Nhóm 1" 
                                   required>
                            <?php $__errorArgs = ['tenhd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                        </div>

                        
                        <div class="mb-3">
                            <label for="ghi_chu" class="form-label fw-bold">Ghi Chú</label>
                            <textarea class="form-control" 
                                      id="ghi_chu" 
                                      name="ghi_chu" 
                                      rows="3" 
                                      placeholder="Ghi chú thêm (nếu có)..."><?php echo e(old('ghi_chu')); ?></textarea>
                        </div>

                        <hr class="my-4">

                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">
                                Chọn Thành Viên Hội Đồng (3-4 người) <span class="text-danger">*</span>
                            </label>

                            <?php $__errorArgs = ['thanh_vien'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div id="thanhVienContainer" class="row">
                                <?php for($i = 1; $i <= 3; $i++): ?>
                                <div class="col-md-6 mb-3 thanhVienItem">
                                    <label class="form-label">
                                        Thành viên <?php echo e($i); ?>

                                        <?php if($i <= 2): ?>
                                            <span class="text-danger">*</span>
                                        <?php endif; ?>
                                    </label>
                                    <div class="input-group">
                                        <select name="thanh_vien[]" 
                                                class="form-select <?php $__errorArgs = ['thanh_vien.'.$i-1];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> giangvienSelect" 
                                                <?php echo e($i <= 3 ? 'required' : ''); ?>>
                                            <option value="">-- Chọn giảng viên --</option>
                                            <?php $__currentLoopData = $danhSachGiangVien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($gv->magv); ?>" 
                                                    <?php echo e((old('thanh_vien.'.$i-1) == $gv->magv) ? 'selected' : ''); ?>>
                                                    <?php echo e($gv->hoten); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        
                                        
                                        <select name="vai_tro[]" 
                                                class="form-select vaiTroSelect"
                                                <?php echo e($i <= 3 ? 'required' : ''); ?>>
                                            <option value="">-- Chọn vai trò --</option>
                                            <option value="chu_tich" <?php echo e(old('vai_tro.'.$i-1) == 'chu_tich' ? 'selected' : ''); ?>>Chủ tịch</option>
                                            <option value="thu_ky" <?php echo e(old('vai_tro.'.$i-1) == 'thu_ky' ? 'selected' : ''); ?>>Thư ký</option>
                                            <option value="thanh_vien" <?php echo e(old('vai_tro.'.$i-1) == 'thanh_vien' ? 'selected' : ''); ?>>Thành viên</option>
                                        </select>
                                    </div>
                                    <?php $__errorArgs = ['thanh_vien.'.$i-1];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <?php endfor; ?>
                            </div>

                            <div class="text-center mb-3">
                                <button type="button" id="themThanhVienBtn" class="btn btn-sm btn-outline-primary">
                                    <i class="fa fa-plus me-1"></i> Thêm Thành Viên Thứ 4 (Tối đa)
                                </button>
                            </div>

                            <div class="alert alert-info mt-3">
                                <i class="fa fa-info-circle me-2"></i>
                                <strong>Lưu ý:</strong>
                                <ul class="mb-0 mt-2">
                                    <li>Hội đồng phải có tối thiểu 3 thành viên, tối đa 4 thành viên</li>
                                    <li>Phải có đúng 1 Chủ tịch và 1 Thư ký</li>
                                    <li>Không được chọn trùng giảng viên</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="card-footer text-center">
                        <button type="submit" class="btn btn-primary btn-lg me-2">
                            <i class="fa fa-save me-2"></i>Tạo Hội Đồng
                        </button>
                        <a href="<?php echo e(route('admin.hoidong.index')); ?>" class="btn btn-secondary btn-lg">
                            <i class="fa fa-arrow-left me-2"></i>Quay Lại
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<script>
document.getElementById('themThanhVienBtn').addEventListener('click', function() {
    const container = document.getElementById('thanhVienContainer');
    const itemCount = document.querySelectorAll('.thanhVienItem').length;
    
    // Chỉ cho thêm nếu chưa đến 4 thành viên
    if (itemCount >= 4) {
        alert('Tối đa 4 thành viên!');
        return;
    }
    
    const newIndex = itemCount;
    const newItem = `
        <div class="col-md-6 mb-3 thanhVienItem">
            <label class="form-label">Thành viên ${itemCount + 1}</label>
            <div class="input-group">
                <select name="thanh_vien[]" class="form-select giangvienSelect">
                    <option value="">-- Chọn giảng viên --</option>
                    <?php $__currentLoopData = $danhSachGiangVien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($gv->magv); ?>"><?php echo e($gv->hoten); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                
                <select name="vai_tro[]" class="form-select vaiTroSelect">
                    <option value="">-- Chọn vai trò --</option>
                    <option value="chu_tich">Chủ tịch</option>
                    <option value="thu_ky">Thư ký</option>
                    <option value="thanh_vien">Thành viên</option>
                </select>
                
                <button type="button" class="btn btn-outline-danger xoaThanhVienBtn">
                    <i class="fa fa-trash"></i>
                </button>
            </div>
        </div>
    `;
    
    const wrapper = document.createElement('div');
    wrapper.innerHTML = newItem;
    container.appendChild(wrapper.firstElementChild);
    
    // Gắn event cho nút xóa
    wrapper.firstElementChild.querySelector('.xoaThanhVienBtn').addEventListener('click', function() {
        wrapper.firstElementChild.remove();
        // Ẩn nút "Thêm" nếu < 4 người
        if (document.querySelectorAll('.thanhVienItem').length < 4) {
            document.getElementById('themThanhVienBtn').style.display = 'inline-block';
        }
    });
    
    // Ẩn nút "Thêm" nếu đã 4 người
    if (itemCount + 1 >= 4) {
        this.style.display = 'none';
    }
});

// Ẩn nút "Thêm" nếu đã có 4 thành viên lúc load trang
window.addEventListener('load', function() {
    if (document.querySelectorAll('.thanhVienItem').length >= 4) {
        document.getElementById('themThanhVienBtn').style.display = 'none';
    }
});
</script>

<style>
.input-group .form-select {
    min-width: 180px;
}
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\QL_LVTN\resources\views/hoidong/create.blade.php ENDPATH**/ ?>