

<?php $__env->startSection('header', 'Chỉnh Sửa Nhóm & Đề Tài'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row justify-content-center">
        <div class="col-lg-8 col-md-10">
            <div class="card shadow">
                <div class="card-header bg-gradient-warning text-dark">
                    <h5 class="mb-0">
                        <i class="fa fa-edit me-2"></i>Chỉnh Sửa Thông Tin Nhóm: <strong><?php echo e($nhom); ?></strong>
                    </h5>
                </div>

                <div class="card-body">
                    
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="fa fa-check-circle me-2"></i><?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="fa fa-exclamation-circle me-2"></i><?php echo e(session('error')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    
                    <div class="alert alert-info mb-4">
                        <h6 class="alert-heading">
                            <i class="fa fa-info-circle me-2"></i>Thông Tin Nhóm
                        </h6>
                        <p class="mb-1"><strong>Mã nhóm:</strong> <?php echo e($nhom); ?></p>
                        <p class="mb-1"><strong>Số thành viên:</strong> <?php echo e($sinhvien->count()); ?></p>
                        <p class="mb-0">
                            <strong>Thành viên:</strong> 
                            <?php $__currentLoopData = $sinhvien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge bg-secondary me-1"><?php echo e($sv->hoten); ?> (<?php echo e($sv->mssv); ?>)</span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p>
                    </div>

                    
                    <form action="<?php echo e(route('lecturers.assignments.update', $nhom)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        
                        <div class="mb-4">
                            <label class="form-label fw-bold">
                                <i class="fa fa-book me-1"></i>Tên Đề Tài 
                                <span class="text-danger">*</span>
                            </label>
                            <textarea class="form-control <?php $__errorArgs = ['tendt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                      name="tendt" 
                                      rows="4" 
                                      required><?php echo e(old('tendt', $detai->tendt)); ?></textarea>
                            <?php $__errorArgs = ['tendt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="mb-4">
                            <label class="form-label fw-bold">
                                <i class="fa fa-flag me-1"></i>Trạng Thái 
                                <span class="text-danger">*</span>
                            </label>
                            <select class="form-select <?php $__errorArgs = ['trangthai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    name="trangthai" 
                                    required>
                                <option value="">-- Chọn trạng thái --</option>
                                <?php $__currentLoopData = $trangThaiList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value); ?>" 
                                            <?php echo e(old('trangthai', $detai->trangthai) == $value ? 'selected' : ''); ?>>
                                        <?php echo e($text); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['trangthai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="d-flex justify-content-between">
                            <div>
                                <button type="submit" class="btn btn-primary btn-lg me-2">
                                    <i class="fa fa-save me-2"></i>Cập Nhật
                                </button>
                                <a href="<?php echo e(route('lecturers.assignments.form')); ?>" class="btn btn-secondary btn-lg">
                                    <i class="fa fa-arrow-left me-2"></i>Quay Lại
                                </a>
                            </div>

                            
                            <form action="<?php echo e(route('lecturers.assignments.destroy', $nhom)); ?>" 
                                  method="POST" 
                                  onsubmit="return confirm('Xác nhận xóa nhóm này? Hành động này không thể hoàn tác!')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-lg">
                                    <i class="fa fa-trash me-2"></i>Xóa Nhóm
                                </button>
                            </form>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.bg-gradient-warning {
    background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\QL_LVTN\resources\views/assignments/edit.blade.php ENDPATH**/ ?>