@extends('layouts.app')

@section('title', 'Trang chủ')
@section('header', 'Home')

@section('content')
<div class="card shadow-sm">
    <div class="card-body">
        <h3 class="text-primary fw-bold">Home</h3>
        <p>Chào mừng bạn đến hệ thống quản lý luận văn tốt nghiệp sinh viên.</p>
    </div>
</div>
@endsection

